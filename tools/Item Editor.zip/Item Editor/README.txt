Sources available in:
https://github.com/ottools/ItemEditor

Credits to Mignari and Contributors:
https://github.com/ottools/ItemEditor/graphs/contributors